CREATE DATABASE  IF NOT EXISTS `mi_inventario` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mi_inventario`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: mi_inventario
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loginlogs`
--

DROP TABLE IF EXISTS `loginlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loginlogs` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `login_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `login_status` enum('success','failure') DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginlogs`
--

LOCK TABLES `loginlogs` WRITE;
/*!40000 ALTER TABLE `loginlogs` DISABLE KEYS */;
INSERT INTO `loginlogs` VALUES (1,NULL,'cliente1@gmail.com','2023-11-02 19:24:16','failure','::1'),(2,NULL,'cliente1@gmail.com','2023-11-02 19:30:03','failure','::1'),(3,NULL,'cliente1@gmail.com','2023-11-02 19:35:35','failure','::1'),(4,NULL,'cliente1@gmail.com','2023-11-02 19:39:12','failure','::1'),(5,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-02 19:42:15','failure','::1'),(6,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-02 19:42:54','success','::1'),(7,NULL,'cliente10@gmail.com','2023-11-02 19:43:15','failure','::1'),(8,NULL,'elkinnocua@gmail.com','2023-11-03 02:41:40','failure','::1'),(9,NULL,'elkinnocua@gmail.com','2023-11-03 02:47:19','failure','::1'),(10,NULL,'elkinnocua@gmail.com','2023-11-03 02:47:35','failure','::1'),(11,NULL,'elkinnocua@gmail.com','2023-11-03 02:47:41','failure','::1'),(12,NULL,'elkinnocua@gmail.com','2023-11-03 02:47:46','failure','::1'),(13,NULL,'elkinnocua@gmail.com','2023-11-03 02:47:46','failure','::1'),(14,NULL,'elkinnocua@gmail.com','2023-11-03 02:47:46','failure','::1'),(15,NULL,'elkinnocua@gmail.com','2023-11-03 02:48:01','failure','::1'),(16,NULL,'elkinnocua@gmail.com','2023-11-03 02:48:01','failure','::1'),(17,NULL,'elkinnocua@gmail.com','2023-11-03 02:48:01','failure','::1'),(18,NULL,'elkinnocua@gmail.com','2023-11-03 02:48:01','failure','::1'),(19,NULL,'elkinnocua@gmail.com','2023-11-03 03:10:32','failure','::1'),(20,NULL,'elkinnocua@gmail.com','2023-11-03 03:10:32','failure','::1'),(21,NULL,'elkinnocua@gmail.com','2023-11-03 03:11:28','failure','::1'),(22,NULL,'elkinnocua@gmail.com','2023-11-03 03:14:39','failure','::1'),(23,NULL,'elkinnocua@gmail.com','2023-11-03 03:20:09','failure','::1'),(24,NULL,'elkinnocua@gmail.com','2023-11-03 03:26:27','failure','::1'),(25,NULL,'elkinnocua@gmail.com','2023-11-03 03:36:08','failure','::1'),(26,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-03 03:38:24','failure','::1'),(27,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-03 03:40:34','success','::1'),(28,NULL,'elkinnocua@gmail.com','2023-11-03 03:49:04','failure','::1'),(29,NULL,'elkinnocua@gmail.com','2023-11-03 03:55:31','failure','::1'),(30,NULL,'elkinnocua@gmail.com','2023-11-03 03:58:38','failure','::1'),(31,NULL,'elkinnocua@gmail.com','2023-11-03 03:59:57','failure','::1'),(32,NULL,'elkinnocua@gmail.com','2023-11-03 04:11:09','failure','::1'),(33,NULL,'elkinnocua@gmail.com','2023-11-03 04:11:13','failure','::1'),(34,NULL,'elkinnocua@gmail.com','2023-11-03 04:11:14','failure','::1'),(35,NULL,'elkinnocua@gmail.com','2023-11-03 04:44:10','failure','::1'),(36,NULL,'elkinnocua@gmail.com','2023-11-03 05:04:35','failure','::1'),(37,NULL,'elkinnocua@gmail.com','2023-11-03 05:09:08','failure','::1'),(38,NULL,'elkinnocua@gmail.com','2023-11-03 05:16:19','failure','::1'),(39,NULL,'elkinnocua@gmail.com','2023-11-03 05:17:03','failure','::1'),(40,NULL,'elkinnocua@gmail.com','2023-11-03 05:24:29','failure','::1'),(41,NULL,'elkinnocua@gmail.com','2023-11-03 05:26:54','failure','::1'),(42,NULL,'elkinnocua@gmail.com','2023-11-03 05:29:27','failure','::1'),(43,NULL,'elkinnocua@gmail.com','2023-11-03 05:34:17','failure','::1'),(44,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-03 05:34:38','failure','::1'),(45,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-03 05:53:25','success','::1'),(46,NULL,'elkinnocua@gmail.com','2023-11-03 07:07:37','failure','::1'),(47,'e138e947-6295-45b5-a080-246019b239bf','cliente1@gmail.com','2023-11-03 07:13:32','failure','::1');
/*!40000 ALTER TABLE `loginlogs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-03  4:31:51
